document.getElementById("button1").addEventListener("click", function() {
    this.classList.toggle("active");
});

document.getElementById("button2").addEventListener("click", function() {
    this.classList.toggle("active");
});

function openPopup(text) {
    var popup = document.getElementById('popup');
    var popupContent = document.getElementById('popupContent');
    popupContent.textContent = text;
    popup.style.display = 'block';
}

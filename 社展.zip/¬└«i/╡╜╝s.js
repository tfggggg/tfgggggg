document.getElementById("販賣機").addEventListener("click", function() {
    this.classList.toggle("active");
});

document.getElementById("小葵").addEventListener("click", function() {
    this.classList.toggle("active");
});
  
document.querySelector(".close").addEventListener("click", function() {
    document.querySelector(".text1").style.opacity = "0";
    document.querySelector(".販賣機-img").style.opacity = "1";
    document.querySelector(".text1").style.zIndex = "";
});

document.querySelector(".close").addEventListener("click", function() {
    document.querySelector(".text2").style.opacity = "0";
    document.querySelector(".小葵-img").style.opacity = "1";
    document.querySelector(".text2").style.zIndex = "";
});

function openPopup(text) {
    var popup = document.getElementById('popup');
    var popupContent = document.getElementById('popupContent');
    popupContent.textContent = text;
    popup.style.display = 'block';
}


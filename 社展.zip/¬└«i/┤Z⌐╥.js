document.getElementById("faucet").addEventListener("click", function() {
    this.classList.toggle("active");
});
  
document.querySelector(".close").addEventListener("click", function() {
    document.querySelector(".text").style.opacity = "0";
    document.querySelector(".faucet-img").style.opacity = "1";
    document.querySelector(".text").style.zIndex = "";
});
  
document.getElementById("button").addEventListener("click", function() {
    window.location.href = "結局.html";
});

function closePopup() {
    var popup = document.getElementById('popup');
    popup.style.display = 'none';
}

function openPopup(text) {
    var popup = document.getElementById('popup');
    var popupContent = document.getElementById('popupContent');
    popupContent.textContent = text;
    popup.style.display = 'block';
}

function closePopup() {
    var popup = document.getElementById('popup');
    popup.style.display = 'none';
}






  
  

  